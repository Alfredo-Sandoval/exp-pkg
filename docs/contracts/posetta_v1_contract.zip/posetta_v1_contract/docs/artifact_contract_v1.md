# Posetta v1 Artifact Contract

Status: Locked for v1
Owner: Posetta
Effective version: `project_schema_version = 1`

## Purpose

This document defines the public on-disk and portable artifact contract for Posetta v1.

The goal is to separate:

1. the **human-facing workspace** used during editing,
2. the **internal mutable store** owned by Posetta, and
3. the **portable project artifact** used for transfer, sharing, and backup.

This contract supersedes the older public framing of native `.siesta` archives as the primary project format.

## Terminology

### Workspace
A workspace is the canonical editable project. It is a normal folder that users open and manage.

Example:

```text
My Project/
```

### Internal store
The internal store is the Posetta-owned mutable state inside the workspace.

Example:

```text
My Project/.posetta/
```

### Portable project artifact
The portable project artifact is a single-file export used to move or share a project.

Example:

```text
My Project.poseproj
```

## Public artifact classes

There are exactly three public artifact classes.

1. **Workspace folder**
2. **Workspace descriptor** (`PROJECT.json`)
3. **Portable project artifact** (`*.poseproj`)

There are no public symlink requirements.
There is no public `.h5` contract.
The internal contents of `.posetta/` are implementation-owned and versioned separately.

## Canonical workspace layout

```text
My Project/
  PROJECT.json
  .posetta/
  Media/
  Exports/
```

Rules:

- `PROJECT.json` is required.
- `.posetta/` is required.
- `Media/` is optional but standard.
- `Exports/` is optional but standard.
- The workspace root is the default unit for opening, copying, and backup.
- Posetta must not require symlinks for project validity.

## Descriptor file: `PROJECT.json`

`PROJECT.json` is the public workspace descriptor.

It must contain only project metadata, layout pointers, and compatibility information.
It must **not** duplicate the full mutable annotation state stored in `.posetta/`.

### Required semantics

- identifies the workspace as a Posetta project
- declares the project schema version
- declares the layout version
- names the store root relative to the workspace root
- identifies standard roots for managed media and exports
- includes stable project identity and timestamps

### Required fields

- `format`
- `project_schema_version`
- `layout_version`
- `title`
- `project_id`
- `created_at`
- `updated_at`
- `store_path`
- `media_root`
- `exports_root`
- `default_pack_mode`

### Default values

- `format = "posetta-project"`
- `project_schema_version = 1`
- `layout_version = 1`
- `store_path = ".posetta"`
- `media_root = "Media"`
- `exports_root = "Exports"`
- `default_pack_mode = "portable"`

## Internal store: `.posetta/`

`.posetta/` is the authoritative mutable state for the project.

Posetta may store the following internally:

- committed snapshots
- journals / WAL state
- immutable objects
- indexes
- manifests
- caches
- locks
- recovery metadata

### Stability rule

The existence of `.posetta/` is public and stable.
Its internal directory structure is **not** part of the long-term public API for v1.

That means Posetta may evolve internal storage layout without changing the public artifact contract, provided that:

- `PROJECT.json` remains valid,
- the workspace still opens correctly,
- migrations are explicit and versioned,
- packed exports unpack into a valid workspace.

## Media semantics

`Media/` is the standard location for managed media that Posetta controls.

Managed media are files copied into the workspace so the project can be made portable.
External media references may exist during active work, but portability rules depend on pack mode.

## Portable project artifact: `*.poseproj`

A `.poseproj` file is a packed project snapshot.

It is the only public portable file type in Posetta v1.

### Rules

- `.poseproj` is a project artifact, not a storage-engine promise.
- Users and third parties must treat it as opaque.
- Posetta may implement it using ZIP, tar+zstd, HDF5-backed payloads, or another container.
- A `.poseproj` file must unpack into a valid workspace.
- Packed exports must come from a committed, validated project state.

### Unpack result

Unpacking `My Project.poseproj` must recreate a workspace with the same logical project state:

```text
My Project/
  PROJECT.json
  .posetta/
  Media/        # if included
```

Logical equivalence is required.
Byte-for-byte identity is not required.
Machine-local locks, temp files, and caches may be regenerated.

## Pack modes

There are exactly two pack modes.

### `portable`
This is the default pack mode.

Guarantee:
The resulting `.poseproj` is expected to open correctly on another machine without requiring unresolved external media.

Rules:

- all required media must be inside `Media/`, or
- required external media must be copied into the packed artifact during pack.
- if Posetta cannot satisfy portability, pack must fail loudly.

No silent omission is allowed.

### `snapshot`
This is an optional state-only export.

Guarantee:
The project state is preserved, but external media may remain external.

Rules:

- the artifact must explicitly declare `pack_mode = "snapshot"`
- opening on another machine may require relinking missing media
- the UI and CLI must not present snapshot exports as fully portable

## Path rules

- Project-internal paths must be stored relative to the workspace root whenever possible.
- Posetta must not require absolute paths for portable correctness.
- Posetta must not require symlink semantics for project validity.
- Posetta may record original source paths in provenance metadata, but these are informative and not authoritative.

## Open behavior

### Primary open target
The primary open target is a workspace folder.

Example:

```text
My Project/
```

### Opening a `.poseproj`
Opening a `.poseproj` file must trigger import/unpack behavior.
Posetta must not edit the packed file in place as if it were the live workspace.

Recommended behavior:

1. choose destination folder
2. unpack into a new workspace
3. open that workspace

## CLI contract

The following commands are part of the v1 artifact workflow.

### Initialize empty workspace

```bash
posetta init "My Project"
```

Creates:

```text
My Project/
  PROJECT.json
  .posetta/
  Media/
  Exports/
```

### Import external data into a workspace

```bash
posetta import dlc csv --csv tracking.csv --video video.mp4 --out "My Project"
posetta import dlc h5 --h5 tracking.h5 --video video.mp4 --out "My Project"
posetta import dlc project --project ./dlc_project --out "My Project"
posetta import sleap --slp labels.pkg.slp --out "My Project"
```

### Pack workspace into portable artifact

```bash
posetta pack "My Project"
```

Default output:

```text
My Project/Exports/My Project.poseproj
```

### Unpack portable artifact into workspace

```bash
posetta unpack "My Project.poseproj" --out "./My Project"
```

### Migrate legacy `.siesta`

```bash
posetta migrate tracking.siesta --out "My Project"
```

## Legacy compatibility policy

### `.siesta`
`.siesta` becomes a legacy import/read format.

Rules for v1:

- Posetta must continue to read/import `.siesta`.
- New projects must be created as workspace folders.
- New portable exports must be `.poseproj`.
- Optional legacy export may exist only behind an explicit compatibility flag.

Example:

```bash
posetta export-legacy "My Project" --out tracking.siesta
```

No new core feature should depend on `.siesta` semantics.

## Public versus private contract

### Public and stable

- workspace root as the primary editable artifact
- `PROJECT.json`
- `.posetta/` as the hidden store root
- `Media/` and `Exports/` as standard top-level folders
- `.poseproj` as the portable artifact suffix
- `portable` and `snapshot` pack modes
- pack / unpack / import / migrate semantics

### Private and versioned

- exact internal `.posetta/` sublayout
- exact storage engine used inside `.posetta/`
- exact packed container format used inside `.poseproj`
- lock implementation details
- temp/cache file layout

## Non-goals for v1

The following are intentionally not part of the public artifact contract:

- direct user editing of `.posetta/`
- exposing a raw `.h5` file as the public portable format
- symlink-based project validity
- byte-level reproducibility of exported artifacts
- a guarantee that external media remain external during `portable` pack

## Example descriptor

```json
{
  "format": "posetta-project",
  "project_schema_version": 1,
  "layout_version": 1,
  "title": "My Project",
  "project_id": "01JPC5KJQ5K4G3A8N2J2Q1B7XZ",
  "created_at": "2026-03-15T00:00:00Z",
  "updated_at": "2026-03-15T00:00:00Z",
  "store_path": ".posetta",
  "media_root": "Media",
  "exports_root": "Exports",
  "default_pack_mode": "portable"
}
```

## Final decision summary

Posetta v1 uses:

- **workspace folder** as the editable artifact
- **`.posetta/`** as the internal mutable store
- **`PROJECT.json`** as the public workspace descriptor
- **`.poseproj`** as the portable project artifact
- **`.siesta`** as legacy import/read compatibility only

This contract is locked for v1.
