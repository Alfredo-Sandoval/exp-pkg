# Posetta v1 CLI Contract

Status: Locked for v1
Owner: Posetta

## Goal

This document defines the CLI surface required to support the Posetta v1 artifact contract.

The existing CLI is conversion-oriented and writes native `.siesta` files directly. The v1 CLI must shift toward a workspace-first model with explicit pack and migration behavior.

## Design principles

1. The primary user object is a **workspace folder**.
2. Imports target a workspace, not a single-file native archive.
3. Portable transfer is an explicit **pack / unpack** operation.
4. Legacy `.siesta` remains supported only for migration and compatibility.
5. Commands must fail loudly on ambiguous or non-portable operations.

## Command groups

The v1 CLI must expose these top-level commands:

- `init`
- `import`
- `pack`
- `unpack`
- `migrate`
- `validate`
- `export-legacy` (optional compatibility path)

## 1. `init`

Create a new empty workspace.

### Syntax

```bash
posetta init <workspace>
```

### Example

```bash
posetta init "My Project"
```

### Result

Creates:

```text
My Project/
  PROJECT.json
  .posetta/
  Media/
  Exports/
```

### Options

- `--title <title>`: explicit project title; defaults to folder name
- `--id <project_id>`: optional explicit project id
- `--force`: allow creation into an existing empty directory

## 2. `import`

Import foreign data into a workspace.

### General rule

`--out` points to a workspace root.
If the workspace does not exist, Posetta may create it.
If the workspace exists, Posetta imports into it.

### Supported subcommands

#### DLC CSV

```bash
posetta import dlc csv --csv tracking.csv --video video.mp4 --out "My Project"
```

Options:
- `--skeleton-name <name>`
- `--threshold <0..1>`

#### DLC H5

```bash
posetta import dlc h5 --h5 tracking.h5 --video video.mp4 --out "My Project"
```

Options:
- `--skeleton-name <name>`
- `--threshold <0..1>`

#### DLC project

```bash
posetta import dlc project --project ./dlc_project --out "My Project"
```

Options:
- `--threshold <0..1>`

#### SLEAP package

```bash
posetta import sleap --slp labels.pkg.slp --out "My Project"
```

Options:
- `--fps <positive int>`
- `--videos`
- `--no-videos`

### Import behavior requirements

- must populate `.posetta/`
- must create or update `PROJECT.json`
- must preserve provenance for the source format, source path, and adapter version
- must fail loudly if import is lossy in a way the user did not approve

## 3. `pack`

Pack a workspace into a portable project artifact.

### Syntax

```bash
posetta pack <workspace>
```

### Default output

```text
<workspace>/Exports/<workspace_name>.poseproj
```

### Examples

```bash
posetta pack "My Project"
posetta pack "My Project" --out ./deliverables/demo.poseproj
posetta pack "My Project" --mode snapshot
```

### Options

- `--out <path>`: explicit output artifact path
- `--mode portable|snapshot`: pack mode, default `portable`
- `--include-media`: explicit opt-in if needed for implementation detail
- `--no-include-media`: only valid with `snapshot`
- `--overwrite`: replace existing output

### Pack behavior requirements

- workspace must validate before packing
- default mode is `portable`
- portable mode must fail if required media cannot be made portable
- resulting artifact suffix must be `.poseproj`

## 4. `unpack`

Unpack a portable project artifact into a workspace.

### Syntax

```bash
posetta unpack <artifact.poseproj> --out <workspace>
```

### Example

```bash
posetta unpack "My Project.poseproj" --out "./My Project"
```

### Options

- `--out <path>`: required destination workspace path
- `--force`: allow overwrite of an empty or replaceable destination
- `--rename <title>`: optional new project title during unpack

### Unpack behavior requirements

- destination must become a valid workspace
- Posetta must not treat `.poseproj` as the editable project itself
- unpack must restore logical project state, not necessarily byte-identical temp/cache files

## 5. `migrate`

Migrate a legacy `.siesta` artifact into a v1 workspace.

### Syntax

```bash
posetta migrate <legacy.siesta> --out <workspace>
```

### Example

```bash
posetta migrate tracking.siesta --out "My Project"
```

### Behavior requirements

- must import labels, predictions, metrics, and provenance supported by the legacy artifact
- must write a v1 `PROJECT.json`
- must populate `.posetta/`
- must report any information that could not be migrated faithfully

## 6. `validate`

Validate a workspace or packed artifact.

### Syntax

```bash
posetta validate <path>
```

### Supported targets

- workspace root
- `PROJECT.json`
- `.poseproj`
- legacy `.siesta`

### Exit behavior

- `0` if valid
- non-zero if invalid or incomplete

### Optional flags

- `--strict`
- `--json`

## 7. `export-legacy`

Optional compatibility command.

### Syntax

```bash
posetta export-legacy <workspace> --out <artifact.siesta>
```

### Policy

- not part of the preferred v1 flow
- may be removed in a later major version
- should require explicit user intent

## Errors and messaging

The CLI must prefer explicit, concrete failure messages.

### Examples

Good:
- `portable pack failed: required media file missing from workspace and could not be copied: Media/session_01.mp4`
- `unpack failed: destination already exists and is not empty`
- `migrate warning: legacy archive contains unsupported extension block 'custom_metrics_v0'; preserved as opaque attachment`

Bad:
- `error`
- `failed to pack project`

## Backward-compatibility notes

The current CLI writes `.siesta` archives directly. The v1 CLI should preserve those pathways only through migration or explicitly named legacy commands.

Recommended aliasing strategy during transition:

- old: `posetta convert ... --out tracking.siesta`
- new: `posetta import ... --out "My Project"`

The help text should make the new artifact model obvious.
